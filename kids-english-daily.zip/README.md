# Kids English Daily (GitHub Pages)

See workflow and scripts.
